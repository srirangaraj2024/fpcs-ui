import logo from './logo.svg';
import './App.css';
import ListEmpComponent from './components/ListEmpComponent';

function App() {
  return (
    <div className="container">
      <ListEmpComponent></ListEmpComponent>
    </div>
  );
}

export default App;
