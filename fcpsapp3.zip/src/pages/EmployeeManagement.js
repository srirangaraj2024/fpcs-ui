import React from 'react'

export const EmployeeManagement = () =>{
  return (
    <div>
      <h2>EmployeeManagement</h2>
    </div>
  )
}
