import React from 'react'

export const Hr = () => {
  return (
    <div>
      <h2>Hr</h2>
    </div>
  );
}
