import React from 'react'

export const LeaveManagement = () =>{
  return (
    <div>
      <h2>Leave Management</h2>

    </div>
  );
}
